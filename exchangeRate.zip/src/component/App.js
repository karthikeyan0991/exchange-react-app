import React,{Component} from 'react';
import ReactDOM from 'react-dom';
import axios from 'axios';
import {Table} from 'antd';
import 'antd/dist/antd.css';

class App extends Component{
	constructor(){
		super();
		this.country = ["INR","AUD","BGN","BRL","CAD","CHF","CNY","CZK","DKK","RON","GBP","HKD","HRK","HUF","IDR","ILS","USD"];
		this.url = " https://api.exchangeratesapi.io/latest?base=";
		this.state = {'columns':[],'dataSource':[]};
		this.inverseStyle = {color: 'red',};
	}
	componentDidMount(){ //when state gets update do the stuff here
		for(let country of this.country){
			axios.get(this.url+country).then((res) => {
				this.createUI(res);
			});
		}
	}
	createUI = (result) => {
		//console.log(result.data);
		this.setState(prevState => ({
		  columns: [ {
		  	'title':result.data.base,
		  	'dataIndex':result.data.base,
		  	'key':result.data.base,
		  }, 
		  ...prevState.columns]
		}));
		Object.keys(this.country).reverse().map((i,k) => {
			if(this.country[i] === result.data.base){
				var o = new Object();
				o.key = k+1;
				o.description = "The above row contains a currency exchnage value of ====>"+ this.country[i];
				Object.keys(this.country).map((m,j) => {
					let valu = this.country[m]
					o[valu] = result.data.rates[this.country[m]];
				});
				this.setState(prevState => ({
				  dataSource: [o, ...prevState.dataSource]
				}));
			}
		})	
	}
	render(){
		return (
			<div>
				<Table columns={this.state.columns} expandedRowRender={record => <p style={{ margin: 0 }}>{record.description}</p>} dataSource={this.state.dataSource} pagination={{ pageSize: 5 }} bordered  footer={() => 'CopyRights Reserved'}/>
			</div>
		)
	}
}

export default App;
